﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A.Models
{
    public enum IdTypes
    {
        NO_VALUE,
        NATIONAL_ID,
        PASSPORT
    }
}
