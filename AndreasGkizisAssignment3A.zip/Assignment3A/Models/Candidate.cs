﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3A.Models
{
    public class Candidate
    {
        public int Id { get; set; }
        public int CandidateNumber { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string NativeLanguage { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Email { get; set; }
        public string LandlineNumber { get; set; }
        public string MobileNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string CountryOfResidence { get; set; }
        public string StateOfResidence { get; set; }
        public string TerritoryOfResidence { get; set; }
        public string ProvinceOfResidence { get; set; }
        public string TownOfResidence { get; set; }
        public string CityOfResidence { get; set; }
        public string PostalCode { get; set; }
        public IdTypes PhotoIdType { get; set; }
        public string PhotoNumber { get; set; }
        public DateTime PhotoIdIssueDate { get; set; }

    }
}
