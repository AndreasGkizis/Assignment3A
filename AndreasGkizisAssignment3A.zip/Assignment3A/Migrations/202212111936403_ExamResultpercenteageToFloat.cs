﻿namespace Assignment3A.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ExamResultpercenteageToFloat : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Examinations", "PercentageScore", c => c.Single(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Examinations", "PercentageScore", c => c.Int(nullable: false));
        }
    }
}
