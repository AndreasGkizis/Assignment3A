﻿namespace Assignment3A.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class withSeed : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Candidates", "PhotoIdType", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Candidates", "PhotoIdType", c => c.String());
        }
    }
}
