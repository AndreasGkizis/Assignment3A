﻿namespace Assignment3A.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class testCascade2 : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.ExaminationTopic_Results", "Examination_Id", "dbo.Examinations");
            DropIndex("dbo.ExaminationTopic_Results", new[] { "Examination_Id" });
            AlterColumn("dbo.ExaminationTopic_Results", "Examination_Id", c => c.Int(nullable: false));
            CreateIndex("dbo.ExaminationTopic_Results", "Examination_Id");
            AddForeignKey("dbo.ExaminationTopic_Results", "Examination_Id", "dbo.Examinations", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ExaminationTopic_Results", "Examination_Id", "dbo.Examinations");
            DropIndex("dbo.ExaminationTopic_Results", new[] { "Examination_Id" });
            AlterColumn("dbo.ExaminationTopic_Results", "Examination_Id", c => c.Int());
            CreateIndex("dbo.ExaminationTopic_Results", "Examination_Id");
            AddForeignKey("dbo.ExaminationTopic_Results", "Examination_Id", "dbo.Examinations", "Id");
        }
    }
}
