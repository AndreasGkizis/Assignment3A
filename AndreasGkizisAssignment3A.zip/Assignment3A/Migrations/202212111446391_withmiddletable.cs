﻿namespace Assignment3A.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class withmiddletable : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.TopicCertificates", "Topic_Id", "dbo.Topics");
            DropForeignKey("dbo.TopicCertificates", "Certificate_Id", "dbo.Certificates");
            DropIndex("dbo.TopicCertificates", new[] { "Topic_Id" });
            DropIndex("dbo.TopicCertificates", new[] { "Certificate_Id" });
            CreateTable(
                "dbo.Certificate_Topics",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Certificate_Id = c.Int(),
                        Topic_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Certificates", t => t.Certificate_Id)
                .ForeignKey("dbo.Topics", t => t.Topic_Id)
                .Index(t => t.Certificate_Id)
                .Index(t => t.Topic_Id);
            
            DropTable("dbo.TopicCertificates");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.TopicCertificates",
                c => new
                    {
                        Topic_Id = c.Int(nullable: false),
                        Certificate_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.Topic_Id, t.Certificate_Id });
            
            DropForeignKey("dbo.Certificate_Topics", "Topic_Id", "dbo.Topics");
            DropForeignKey("dbo.Certificate_Topics", "Certificate_Id", "dbo.Certificates");
            DropIndex("dbo.Certificate_Topics", new[] { "Topic_Id" });
            DropIndex("dbo.Certificate_Topics", new[] { "Certificate_Id" });
            DropTable("dbo.Certificate_Topics");
            CreateIndex("dbo.TopicCertificates", "Certificate_Id");
            CreateIndex("dbo.TopicCertificates", "Topic_Id");
            AddForeignKey("dbo.TopicCertificates", "Certificate_Id", "dbo.Certificates", "Id", cascadeDelete: true);
            AddForeignKey("dbo.TopicCertificates", "Topic_Id", "dbo.Topics", "Id", cascadeDelete: true);
        }
    }
}
