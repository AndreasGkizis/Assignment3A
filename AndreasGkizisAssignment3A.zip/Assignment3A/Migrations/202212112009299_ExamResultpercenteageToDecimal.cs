﻿namespace Assignment3A.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ExamResultpercenteageToDecimal : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Examinations", "PercentageScore", c => c.Decimal(nullable: false, precision: 18, scale: 2));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Examinations", "PercentageScore", c => c.Int(nullable: false));
        }
    }
}
