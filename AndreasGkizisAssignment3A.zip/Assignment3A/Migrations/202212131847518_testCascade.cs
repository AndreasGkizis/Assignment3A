﻿namespace Assignment3A.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class testCascade : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Examinations", "Candidate_Id_Id", "dbo.Candidates");
            DropIndex("dbo.Examinations", new[] { "Candidate_Id_Id" });
            AlterColumn("dbo.Examinations", "Candidate_Id_Id", c => c.Int(nullable: false));
            CreateIndex("dbo.Examinations", "Candidate_Id_Id");
            AddForeignKey("dbo.Examinations", "Candidate_Id_Id", "dbo.Candidates", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Examinations", "Candidate_Id_Id", "dbo.Candidates");
            DropIndex("dbo.Examinations", new[] { "Candidate_Id_Id" });
            AlterColumn("dbo.Examinations", "Candidate_Id_Id", c => c.Int());
            CreateIndex("dbo.Examinations", "Candidate_Id_Id");
            AddForeignKey("dbo.Examinations", "Candidate_Id_Id", "dbo.Candidates", "Id");
        }
    }
}
