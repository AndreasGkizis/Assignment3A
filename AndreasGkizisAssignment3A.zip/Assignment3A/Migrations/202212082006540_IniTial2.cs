﻿namespace Assignment3A.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class IniTial2 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ExaminationTopic_Results",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AwardedMarks = c.Int(nullable: false),
                        Examination_Id = c.Int(),
                        Topic_Id = c.Int(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Examinations", t => t.Examination_Id)
                .ForeignKey("dbo.Topics", t => t.Topic_Id)
                .Index(t => t.Examination_Id)
                .Index(t => t.Topic_Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ExaminationTopic_Results", "Topic_Id", "dbo.Topics");
            DropForeignKey("dbo.ExaminationTopic_Results", "Examination_Id", "dbo.Examinations");
            DropIndex("dbo.ExaminationTopic_Results", new[] { "Topic_Id" });
            DropIndex("dbo.ExaminationTopic_Results", new[] { "Examination_Id" });
            DropTable("dbo.ExaminationTopic_Results");
        }
    }
}
