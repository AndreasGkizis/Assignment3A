﻿namespace Assignment3A.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ExamResultpercenteageToInt : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Examinations", "PercentageScore", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Examinations", "PercentageScore", c => c.Single(nullable: false));
        }
    }
}
