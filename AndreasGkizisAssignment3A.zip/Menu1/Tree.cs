﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Menu1
{
    public class Tree
    {
        public static void SomeTree()
        {
            Console.WriteLine("             /\\");
            Console.WriteLine("            <  >");
            Console.WriteLine("             \\/");
            Console.WriteLine("             /\\");
            Console.WriteLine("            /  \\");
            Console.WriteLine("           /++++\\");
            Console.WriteLine("          /  ()  \\");
            Console.WriteLine("          /      \\");
            Console.WriteLine("         /~`~`~`~`\\");
            Console.WriteLine("        / ()   ()  \\");
            Console.WriteLine("        /          \\");
            Console.WriteLine("       /*&*&*&*&*&*&\\");
            Console.WriteLine("      /  ()  ()  ()  \\");
            Console.WriteLine("      /              \\");
            Console.WriteLine("     /++++++++++++++++\\");
            Console.WriteLine("    /  ()  ()  ()  ()  \\");
            Console.WriteLine("    /                  \\");
            Console.WriteLine("   /~`~`~`~`~`~`~`~`~`~`\\");
            Console.WriteLine("  / ()  ()  ()  ()  ()   \\");
            Console.WriteLine("  /*&*&*&*&*&*&*&*&*&*&*&\\        ──────╔╦╗╔╗╔╗╔╗╗╔───────");
            Console.WriteLine(" /                        \\       ──────║║║╠─║─║─╚╣───────");
            Console.WriteLine("/,.,.,.,.,.,.,.,.,.,.,.,.,.\\      ──────╝─╚╚╝╩─╩─╚╝───────");
            Console.WriteLine("           || ||                   ╔═╗╗─╔╔╗─╦╔═╗╔╦╗╔╦╗╔╗╔═╗");
            Console.WriteLine("          |`````|                  ║──╠═╣╠╩╗║╚═╗─║─║║║╠╣╚═╗");
            Console.WriteLine("          \\_____/                  ╚═╝╝─╚╝─╩╩╚═╝─╩─╝╩╚╩╩╚═╝\n\n");
            Console.WriteLine("Press any key to proceed");
            Console.ReadKey();

        }
            
    }
}
